import { NextResponse, after } from 'next/server';
import connectDB from '@/lib/mongodb';
import Assessment from '@/models/Assessment';
import TestRun from '@/models/TestRun';
import ApprovedTarget from '@/models/ApprovedTarget';
import AuditLog from '@/models/AuditLog';
import { requireAuth, checkOrganizationAccess, ROLES } from '@/lib/auth';
import { executeInspectionRun } from '@/lib/assessment-runner';
import { emitAssessmentEvent } from '@/lib/event-bus';
import { validateTargetUrl } from '@/lib/security';

export const dynamic = 'force-dynamic';
export const maxDuration = 300;

/**
 * POST /api/assessments/[id]/reassess
 * Creates a brand new Assessment and TestRun for the same website,
 * strictly preserving previous findings, reports, and evidence.
 */
export async function POST(request, { params }) {
  try {
    const { session, errorResponse } = requireAuth(request);
    if (errorResponse) return errorResponse;

    await connectDB();
    const resolvedParams = await params;
    const { id } = resolvedParams;

    if (!id) {
      return NextResponse.json({ success: false, error: 'Assessment ID is required.' }, { status: 400 });
    }

    const prevAssessment = await Assessment.findById(id).populate('organization');
    if (!prevAssessment) {
      return NextResponse.json({ success: false, error: 'Assessment not found.' }, { status: 404 });
    }

    const targetOrgId = prevAssessment.organization?._id || prevAssessment.organization;

    // RBAC: Verify ownership (unless platform admin or reviewer)
    if (!checkOrganizationAccess(session, targetOrgId)) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized: You do not have permission to reassess this website.' },
        { status: 403 }
      );
    }

    // Parse domain from target URL
    let parsedUrl;
    try {
      parsedUrl = new URL(prevAssessment.targetUrl);
    } catch (e) {
      return NextResponse.json({ success: false, error: 'Malformed target URL.' }, { status: 400 });
    }
    const domain = parsedUrl.hostname;

    // Verify ApprovedTarget status is approved
    const approvedTarget = await ApprovedTarget.findOne({
      organization: targetOrgId,
      approvedDomain: domain,
      targetStatus: 'approved',
    });

    if (!approvedTarget) {
      return NextResponse.json(
        {
          success: false,
          error: `Target domain '${domain}' is not in approved status. Reassessment cannot proceed until domain is approved.`,
        },
        { status: 403 }
      );
    }

    // SSRF & Domain validation
    const isDemoSite = Boolean(approvedTarget.isDemoSite);
    const urlCheck = validateTargetUrl(prevAssessment.targetUrl, { allowDemoLocalhost: isDemoSite });
    if (!urlCheck.isValid) {
      return NextResponse.json(
        { success: false, error: `Invalid target URL: ${urlCheck.reason}` },
        { status: 400 }
      );
    }

    // Check for an active reassessment already running for this target to prevent duplicate clicks
    const existingActiveRun = await TestRun.findOne({
      targetId: approvedTarget._id,
      status: { $in: ['queued', 'starting_browser', 'inspecting_website', 'capturing_evidence', 'running'] },
      updatedAt: { $gte: new Date(Date.now() - 60 * 1000) },
    });

    if (existingActiveRun) {
      return NextResponse.json(
        {
          success: false,
          error: 'An automated assessment is already actively running for this website. Please wait for it to complete.',
          activeRunId: existingActiveRun._id,
          activeAssessmentId: existingActiveRun.assessmentId,
          assessmentId: existingActiveRun.assessmentId,
          testRunId: existingActiveRun._id,
        },
        { status: 409 }
      );
    }

    const body = await request.json().catch(() => ({}));
    const { scopeConfig = {}, notes } = body;

    // Handle authentication configuration safely
    const isPublicOnly = scopeConfig.skipAuthenticatedTesting !== false;
    let authOptions = {
      enabled: false,
      authMethod: 'public_only',
      skipAuthenticatedTesting: true,
    };

    if (!isPublicOnly) {
      const loginUrl = (scopeConfig.testLoginUrl || '').trim();
      const username = (scopeConfig.testUsername || '').trim();
      const password = scopeConfig.testPassword || '';

      if (!loginUrl || !username || !password) {
        return NextResponse.json(
          {
            success: false,
            error: 'When authenticated testing is enabled, Login URL, Username, and Password are all required.',
          },
          { status: 400 }
        );
      }

      // Check login domain against approved domain
      try {
        const loginDomain = new URL(loginUrl).hostname.replace(/^www\./, '').toLowerCase();
        const baseTargetDomain = approvedTarget.approvedDomain.replace(/^www\./, '').toLowerCase();
        if (loginDomain !== baseTargetDomain && !loginDomain.endsWith(`.${baseTargetDomain}`)) {
          return NextResponse.json(
            {
              success: false,
              error: `Login URL domain '${loginDomain}' does not belong to authorized target '${approvedTarget.approvedDomain}'.`,
            },
            { status: 400 }
          );
        }
      } catch (e) {
        return NextResponse.json(
          { success: false, error: 'Invalid login page URL format.' },
          { status: 400 }
        );
      }

      authOptions = {
        enabled: true,
        authMethod: 'password',
        loginUrl,
        username,
        password, // passed in memory to assessment runner, NEVER saved to database or logs
        skipAuthenticatedTesting: false,
      };
    }

    // Compute sequential run number based on previous assessment sequence
    const sequenceNumber = (prevAssessment.sequenceNumber || 1) + 1;

    // Create the NEW Assessment record
    const newAssessment = await Assessment.create({
      organization: targetOrgId,
      targetUrl: prevAssessment.targetUrl,
      websiteName: prevAssessment.websiteName,
      status: 'queued',
      modelUsed: prevAssessment.modelUsed || 'gemini-3.8-flash',
      testMode: prevAssessment.testMode || 'hybrid',
      previousAssessmentId: prevAssessment._id,
      rootAssessmentId: prevAssessment.rootAssessmentId || prevAssessment._id,
      sequenceNumber,
      isReassessment: true,
      scopeConfig: {
        skipAuthenticatedTesting: isPublicOnly,
        hasAuthTesting: !isPublicOnly,
        testLoginUrl: !isPublicOnly ? authOptions.loginUrl : null,
        testUsername: !isPublicOnly ? authOptions.username : null,
      },
      triggeredBy: session.userId || null,
      notes: notes || `Reassessment Run #${sequenceNumber} (rerun of assessment ${String(prevAssessment._id).slice(-8)})`,
    });

    // Create new TestRun record in queued state
    const testRun = await TestRun.create({
      assessmentId: newAssessment._id,
      targetId: approvedTarget._id,
      status: 'queued',
      progress: 0,
      currentStep: `Queued for automated Playwright reassessment (Run #${sequenceNumber})`,
      maxPages: 15,
      maxActions: 50,
      timeoutSeconds: 120,
    });

    // Record AuditLog without password
    await AuditLog.create({
      action: 'ASSESSMENT_REASSESSMENT_QUEUED',
      category: 'assessment',
      actor: {
        userId: session.userId || null,
        email: session.email || 'customer',
      },
      target: {
        entityType: 'Assessment',
        entityId: newAssessment._id,
        identifier: prevAssessment.targetUrl,
      },
      details: {
        newAssessmentId: newAssessment._id,
        previousAssessmentId: prevAssessment._id,
        sequenceNumber,
        targetDomain: urlCheck.domain,
        authMethod: authOptions.authMethod,
      },
      status: 'success',
    });

    // Emit initial queue event
    await emitAssessmentEvent({
      assessmentId: newAssessment._id,
      testRunId: testRun._id,
      eventType: 'queued',
      title: `Reassessment Queued (Run #${sequenceNumber})`,
      description: `Fresh reassessment initiated for ${urlCheck.domain}. Previous run #${prevAssessment.sequenceNumber || 1} report remains preserved.`,
      progress: 0,
      stepName: `Queued for Playwright reassessment (Run #${sequenceNumber})`,
      url: prevAssessment.targetUrl,
    });

    // Check if caller explicitly requested synchronous completion (e.g. CLI test scripts)
    const isSyncRequested = Boolean(body?.sync);

    if (isSyncRequested) {
      // Synchronous execution path (e.g. CLI automated test suites)
      try {
        await executeInspectionRun(testRun._id, authOptions);
      } catch (runErr) {
        console.error(`[Direct Reassessment Error for ${testRun._id}]:`, runErr);
      }

      const [finishedRun, finishedAssessment] = await Promise.all([
        TestRun.findById(testRun._id).lean(),
        Assessment.findById(newAssessment._id).lean(),
      ]);

      const isSuccess = finishedRun?.status === 'completed';

      return NextResponse.json(
        {
          success: true,
          message: isSuccess
            ? `Reassessment Run #${sequenceNumber} completed successfully.`
            : `Reassessment Run #${sequenceNumber} finished with status: ${finishedRun?.status || 'failed'}.`,
          assessmentId: String(newAssessment._id),
          testRunId: String(testRun._id),
          sequenceNumber,
          previousAssessmentId: String(prevAssessment._id),
          testRun: finishedRun || testRun,
          assessment: finishedAssessment || newAssessment,
          isCompleted: isSuccess,
          error: isSuccess ? null : (finishedRun?.errorMessage || 'Reassessment encountered errors'),
        },
        { status: 200 }
      );
    }

    // Direct asynchronous execution: schedule runner in background and return immediate assessmentId for live stream navigation
    try {
      after(async () => {
        try {
          await executeInspectionRun(testRun._id, authOptions);
        } catch (runErr) {
          console.error(`[Background Reassessment Error for ${testRun._id}]:`, runErr);
        }
      });
    } catch (afterErr) {
      executeInspectionRun(testRun._id, authOptions).catch((runErr) => {
        console.error(`[Background Reassessment Error for ${testRun._id}]:`, runErr);
      });
    }

    return NextResponse.json(
      {
        success: true,
        message: `Reassessment Run #${sequenceNumber} initiated. Live inspection running in real-time.`,
        assessmentId: String(newAssessment._id),
        testRunId: String(testRun._id),
        sequenceNumber,
        previousAssessmentId: String(prevAssessment._id),
        status: 'running',
        isCompleted: false,
      },
      { status: 200 }
    );
  } catch (err) {
    console.error('Error initiating reassessment:', err);
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
