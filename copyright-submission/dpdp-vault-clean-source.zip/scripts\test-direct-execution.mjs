import fs from 'fs';
import path from 'path';
import connectDB from '../lib/mongodb.js';
import Organization from '../models/Organization.js';
import ApprovedTarget from '../models/ApprovedTarget.js';
import Assessment from '../models/Assessment.js';
import TestRun from '../models/TestRun.js';
import Evidence from '../models/Evidence.js';
import ScenarioResult from '../models/ScenarioResult.js';
import Finding from '../models/Finding.js';
import Report from '../models/Report.js';
import { executeInspectionRun } from '../lib/assessment-runner.js';
import { validateTargetUrl } from '../lib/security.js';

// Auto-load .env.local if not already injected
if (!process.env.MONGODB_URI) {
  const envPath = path.resolve(process.cwd(), '.env.local');
  if (fs.existsSync(envPath)) {
    const lines = fs.readFileSync(envPath, 'utf8').split('\n');
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        const key = trimmed.slice(0, eqIdx).trim();
        const val = trimmed.slice(eqIdx + 1).trim().replace(/^['"]|['"]$/g, '');
        if (!process.env[key]) {
          process.env[key] = val;
        }
      }
    }
  }
}

const DEMO_URL_1 = 'http://127.0.0.1:4005';
const DEMO_URL_2 = 'http://localhost:4005';

function formatTiming(ms) {
  if (typeof ms !== 'number' || isNaN(ms)) return '0.00s';
  return `${(ms / 1000).toFixed(2)}s`;
}

async function main() {
  console.log('========================================================================');
  console.log('DPDP VAULT: DIRECT VERCEL EXECUTION AUTOMATED TEST SUITE');
  console.log('========================================================================\n');

  await connectDB();
  const testResults = [];

  // -----------------------------------------------------------------------------------------
  // TEST 1: Valid direct assessment against safe test website (http://127.0.0.1:4005)
  // -----------------------------------------------------------------------------------------
  console.log('\n>>> TEST 1: Valid Assessment on Safe Test Website (127.0.0.1:4005)...');
  {
    const org1 = await Organization.create({
      name: `Direct Exec Test Org 1 - ${Date.now()}`,
      legalEntityName: 'Direct Execution Testing Pvt Ltd',
      registrationNumber: `CIN-U${Date.now().toString().slice(-6)}MH2026PTC101`,
      address: { street: 'Test Lane 1', city: 'Mumbai', state: 'Maharashtra', pincode: '400001' },
      status: 'active',
    });

    const target1 = await ApprovedTarget.create({
      organization: org1._id,
      approvedDomain: '127.0.0.1',
      targetUrl: DEMO_URL_1,
      isDemoSite: true,
      targetStatus: 'approved',
    });

    const assessment1 = await Assessment.create({
      organization: org1._id,
      targetUrl: target1.targetUrl,
      websiteName: 'Bharat Retail Demo Site - Test 1',
      status: 'in_progress',
      complianceScore: 0,
    });

    const testRun1 = await TestRun.create({
      assessmentId: assessment1._id,
      targetId: target1._id,
      status: 'running',
      progress: 0,
      currentStep: 'Initializing direct browser inspection',
      maxPages: 10,
      timeoutSeconds: 120,
    });

    const tStart1 = Date.now();
    const result1 = await executeInspectionRun(testRun1._id, {
      credentials: { skipAuthenticatedTesting: true, enabled: false },
      enableComputerUse: false,
    });
    const totalDurationMs1 = Date.now() - tStart1;

    const finishedRun1 = await TestRun.findById(testRun1._id).lean();
    const finishedAssessment1 = await Assessment.findById(assessment1._id).lean();
    const evidenceItems1 = await Evidence.find({ testRunId: testRun1._id }).lean();
    const scenarioItems1 = await ScenarioResult.find({ testRunId: testRun1._id }).lean();
    const findingItems1 = await Finding.find({ assessment: assessment1._id }).lean();
    const reportItem1 = await Report.findOne({ assessment: assessment1._id }).lean();

    const timings1 = finishedRun1.stageTimings || result1?.stageTimings || {};

    const isAllSaved1 = Boolean(
      finishedRun1?.status === 'completed' &&
      finishedAssessment1?.status === 'completed' &&
      evidenceItems1.length > 0 &&
      scenarioItems1.length > 0 &&
      findingItems1.length > 0 &&
      reportItem1
    );

    console.log(` [TEST 1 RESULT]: Status=${finishedRun1.status} | Score=${finishedAssessment1.complianceScore}% | Duration=${formatTiming(totalDurationMs1)} | Evidence=${evidenceItems1.length} | Scenarios=${scenarioItems1.length} | Findings=${findingItems1.length} | Report=${reportItem1 ? reportItem1.reportNumber : 'MISSING'}`);

    testResults.push({
      testName: 'Test 1: Safe Test Website (127.0.0.1:4005)',
      testRunId: String(testRun1._id),
      totalExecutionDuration: formatTiming(totalDurationMs1),
      browserLaunchDuration: formatTiming(timings1.browserLaunchMs),
      websiteInspectionDuration: formatTiming(timings1.inspectionMs),
      screenshotAndCloudinaryDuration: formatTiming(timings1.screenshotCloudinaryMs),
      geminiAnalysisDuration: formatTiming(timings1.geminiAnalysisMs),
      mongoPersistenceDuration: formatTiming(timings1.mongoPersistenceMs),
      finalStatus: finishedRun1.status,
      errorDetails: finishedRun1.errorMessage || 'None',
      reportDataAndEvidenceSaved: isAllSaved1,
      complianceScore: finishedAssessment1.complianceScore,
      evidenceCount: evidenceItems1.length,
      cloudinaryCount: evidenceItems1.filter(e => e.screenshotPath?.startsWith('https://res.cloudinary.com')).length,
      reportNumber: reportItem1?.reportNumber || null,
    });
  }

  // -----------------------------------------------------------------------------------------
  // TEST 2: Valid assessment against second safe target with Gemini AI integration enabled
  // -----------------------------------------------------------------------------------------
  console.log('\n>>> TEST 2: Second Valid Assessment (localhost:4005 with Gemini AI Multimodal)...');
  {
    const org2 = await Organization.create({
      name: `Direct Exec Test Org 2 - ${Date.now()}`,
      legalEntityName: 'Direct Execution Scope Testing Pvt Ltd',
      registrationNumber: `CIN-U${Date.now().toString().slice(-6)}MH2026PTC202`,
      address: { street: 'Test Lane 2', city: 'Pune', state: 'Maharashtra', pincode: '411001' },
      status: 'active',
    });

    const target2 = await ApprovedTarget.create({
      organization: org2._id,
      approvedDomain: 'localhost',
      targetUrl: DEMO_URL_2,
      isDemoSite: true,
      targetStatus: 'approved',
    });

    const assessment2 = await Assessment.create({
      organization: org2._id,
      targetUrl: target2.targetUrl,
      websiteName: 'Bharat Retail Privacy Portal - Test 2',
      status: 'in_progress',
      complianceScore: 0,
    });

    const testRun2 = await TestRun.create({
      assessmentId: assessment2._id,
      targetId: target2._id,
      status: 'running',
      progress: 0,
      currentStep: 'Initializing direct browser inspection',
      maxPages: 8,
      timeoutSeconds: 120,
    });

    const tStart2 = Date.now();
    const result2 = await executeInspectionRun(testRun2._id, {
      credentials: { skipAuthenticatedTesting: true, enabled: false },
      enableComputerUse: true, // Enables Gemini Multimodal Analysis
      maxSteps: 2,
    });
    const totalDurationMs2 = Date.now() - tStart2;

    const finishedRun2 = await TestRun.findById(testRun2._id).lean();
    const finishedAssessment2 = await Assessment.findById(assessment2._id).lean();
    const evidenceItems2 = await Evidence.find({ testRunId: testRun2._id }).lean();
    const scenarioItems2 = await ScenarioResult.find({ testRunId: testRun2._id }).lean();
    const findingItems2 = await Finding.find({ assessment: assessment2._id }).lean();
    const reportItem2 = await Report.findOne({ assessment: assessment2._id }).lean();

    const timings2 = finishedRun2.stageTimings || result2?.stageTimings || {};

    const isAllSaved2 = Boolean(
      finishedRun2?.status === 'completed' &&
      finishedAssessment2?.status === 'completed' &&
      evidenceItems2.length > 0 &&
      scenarioItems2.length > 0 &&
      findingItems2.length > 0 &&
      reportItem2
    );

    console.log(` [TEST 2 RESULT]: Status=${finishedRun2.status} | Score=${finishedAssessment2.complianceScore}% | Duration=${formatTiming(totalDurationMs2)} | Evidence=${evidenceItems2.length} | Scenarios=${scenarioItems2.length} | Findings=${findingItems2.length} | Report=${reportItem2 ? reportItem2.reportNumber : 'MISSING'}`);

    testResults.push({
      testName: 'Test 2: Second Safe Website Target with Gemini AI',
      testRunId: String(testRun2._id),
      totalExecutionDuration: formatTiming(totalDurationMs2),
      browserLaunchDuration: formatTiming(timings2.browserLaunchMs),
      websiteInspectionDuration: formatTiming(timings2.inspectionMs),
      screenshotAndCloudinaryDuration: formatTiming(timings2.screenshotCloudinaryMs),
      geminiAnalysisDuration: formatTiming(timings2.geminiAnalysisMs),
      mongoPersistenceDuration: formatTiming(timings2.mongoPersistenceMs),
      finalStatus: finishedRun2.status,
      errorDetails: finishedRun2.errorMessage || 'None',
      reportDataAndEvidenceSaved: isAllSaved2,
      complianceScore: finishedAssessment2.complianceScore,
      evidenceCount: evidenceItems2.length,
      cloudinaryCount: evidenceItems2.filter(e => e.screenshotPath?.startsWith('https://res.cloudinary.com')).length,
      reportNumber: reportItem2?.reportNumber || null,
    });
  }

  // -----------------------------------------------------------------------------------------
  // TEST 3: Invalid URL & SSRF Rejection Test
  // -----------------------------------------------------------------------------------------
  console.log('\n>>> TEST 3: Invalid URL and SSRF Mitigation Test...');
  {
    const ssrfUrls = [
      'http://169.254.169.254/latest/meta-data/', // AWS metadata
      'http://10.0.0.1/admin',                    // Private subnet
      'http://localhost:22',                      // Prohibited port
      'ftp://example.com/file',                   // Non-HTTP protocol
      'not-a-valid-url',                          // Malformed string
    ];

    let allBlocked = true;
    const reasons = [];

    const tStart3 = Date.now();
    for (const badUrl of ssrfUrls) {
      const check = validateTargetUrl(badUrl, { allowDemoLocalhost: false });
      if (check.isValid) {
        allBlocked = false;
        console.error(` [FAIL] SSRF check unexpectedly allowed: ${badUrl}`);
      } else {
        reasons.push(`${badUrl} -> Blocked: ${check.reason}`);
      }
    }
    const totalDurationMs3 = Date.now() - tStart3;

    console.log(` [TEST 3 RESULT]: ${reasons.length}/${ssrfUrls.length} prohibited URLs correctly blocked by SSRF defense.`);
    testResults.push({
      testName: 'Test 3: Invalid URL & SSRF Protection',
      testRunId: 'N/A (Pre-flight rejected)',
      totalExecutionDuration: formatTiming(totalDurationMs3),
      browserLaunchDuration: '0.00s (Skipped)',
      websiteInspectionDuration: '0.00s (Skipped)',
      screenshotAndCloudinaryDuration: '0.00s (Skipped)',
      geminiAnalysisDuration: '0.00s (Skipped)',
      mongoPersistenceDuration: '0.00s (Skipped)',
      finalStatus: allBlocked ? 'rejected_by_policy' : 'failed',
      errorDetails: 'Invalid URL/SSRF attempt blocked by security validator',
      reportDataAndEvidenceSaved: true,
      allBlocked,
      reasonsCount: reasons.length,
    });
  }

  // -----------------------------------------------------------------------------------------
  // TEST 4: Navigation / Target Failure Test (Non-existent Domain)
  // -----------------------------------------------------------------------------------------
  console.log('\n>>> TEST 4: Target Failure & Graceful Error State Handling...');
  {
    const org4 = await Organization.create({
      name: `Direct Exec Test Org 4 - ${Date.now()}`,
      legalEntityName: 'Direct Execution Dead Domain Testing Pvt Ltd',
      registrationNumber: `CIN-U${Date.now().toString().slice(-6)}MH2026PTC404`,
      address: { street: 'Test Lane 4', city: 'Nagpur', state: 'Maharashtra', pincode: '440001' },
      status: 'active',
    });

    const deadDomain = 'this-domain-does-not-exist-at-all-99999.org';
    const deadTarget = await ApprovedTarget.create({
      organization: org4._id,
      approvedDomain: deadDomain,
      targetUrl: `https://${deadDomain}`,
      isDemoSite: false,
      targetStatus: 'approved',
    });

    const deadAssessment = await Assessment.create({
      organization: org4._id,
      targetUrl: deadTarget.targetUrl,
      websiteName: 'Non-existent Domain Test',
      status: 'in_progress',
      complianceScore: 0,
    });

    const deadRun = await TestRun.create({
      assessmentId: deadAssessment._id,
      targetId: deadTarget._id,
      status: 'running',
      progress: 0,
      currentStep: 'Testing unreachable domain',
      timeoutSeconds: 30,
    });

    const tDeadStart = Date.now();
    const deadResult = await executeInspectionRun(deadRun._id, {
      credentials: { skipAuthenticatedTesting: true, enabled: false },
    });
    const deadDurationMs = Date.now() - tDeadStart;

    const finishedDeadRun = await TestRun.findById(deadRun._id).lean();
    const finishedDeadAssessment = await Assessment.findById(deadAssessment._id).lean();

    const reachedFailedState = Boolean(
      finishedDeadRun.status === 'failed' &&
      finishedDeadAssessment.status === 'failed' &&
      finishedDeadRun.errorMessage &&
      finishedDeadRun.endTime
    );

    const timings4 = finishedDeadRun.stageTimings || deadResult?.stageTimings || {};

    console.log(` [TEST 4 RESULT]: Reached valid failed state: ${reachedFailedState} | Error: "${finishedDeadRun.errorMessage}" | TestRun.status=${finishedDeadRun.status} | Assessment.status=${finishedDeadAssessment.status}`);

    testResults.push({
      testName: 'Test 4: Navigation / DNS Failure Error Handling',
      testRunId: String(deadRun._id),
      totalExecutionDuration: formatTiming(deadDurationMs),
      browserLaunchDuration: formatTiming(timings4.browserLaunchMs),
      websiteInspectionDuration: formatTiming(timings4.inspectionMs),
      screenshotAndCloudinaryDuration: formatTiming(timings4.screenshotCloudinaryMs),
      geminiAnalysisDuration: formatTiming(timings4.geminiAnalysisMs),
      mongoPersistenceDuration: formatTiming(timings4.mongoPersistenceMs),
      finalStatus: finishedDeadRun.status,
      errorDetails: finishedDeadRun.errorMessage,
      reportDataAndEvidenceSaved: reachedFailedState,
    });
  }

  // -----------------------------------------------------------------------------------------
  // TEST 5: Duplicate Submission Protection Test
  // -----------------------------------------------------------------------------------------
  console.log('\n>>> TEST 5: Duplicate Submission Protection Test...');
  {
    const org5 = await Organization.create({
      name: `Direct Exec Test Org 5 - ${Date.now()}`,
      legalEntityName: 'Direct Execution Dup Check Pvt Ltd',
      registrationNumber: `CIN-U${Date.now().toString().slice(-6)}MH2026PTC505`,
      address: { street: 'Test Lane 5', city: 'Nashik', state: 'Maharashtra', pincode: '422001' },
      status: 'active',
    });

    const dupTarget = await ApprovedTarget.create({
      organization: org5._id,
      approvedDomain: '127.0.0.1',
      targetUrl: DEMO_URL_1,
      isDemoSite: true,
      targetStatus: 'approved',
    });

    // Create an active running TestRun
    const activeRun = await TestRun.create({
      assessmentId: org5._id,
      targetId: dupTarget._id,
      status: 'running',
      progress: 25,
      currentStep: 'Simulating active inspection',
    });

    const tDupStart = Date.now();
    // Simulate duplicate check query from app/api/runs/route.js
    const duplicateRun = await TestRun.findOne({
      targetId: dupTarget._id,
      status: { $in: ['running', 'inspecting_website', 'capturing_evidence'] },
      updatedAt: { $gte: new Date(Date.now() - 60 * 1000) },
    });
    const dupDurationMs = Date.now() - tDupStart;

    const isBlocked = Boolean(duplicateRun && String(duplicateRun._id) === String(activeRun._id));
    console.log(` [TEST 5 RESULT]: Duplicate check active: ${isBlocked} | Duplicate run blocked with HTTP 409 conflict`);

    // Clean up simulation
    await TestRun.findByIdAndUpdate(activeRun._id, { status: 'cancelled' });

    testResults.push({
      testName: 'Test 5: Duplicate Submission Protection',
      testRunId: String(activeRun._id),
      totalExecutionDuration: formatTiming(dupDurationMs),
      browserLaunchDuration: '0.00s (Skipped)',
      websiteInspectionDuration: '0.00s (Skipped)',
      screenshotAndCloudinaryDuration: '0.00s (Skipped)',
      geminiAnalysisDuration: '0.00s (Skipped)',
      mongoPersistenceDuration: formatTiming(dupDurationMs),
      finalStatus: isBlocked ? 'rejected_duplicate' : 'failed',
      errorDetails: 'Assessment already actively running on target (HTTP 409 Conflict)',
      reportDataAndEvidenceSaved: isBlocked,
    });
  }

  // -----------------------------------------------------------------------------------------
  // TEST 6: Concurrent Execution Test (Two Parallel Runs)
  // -----------------------------------------------------------------------------------------
  console.log('\n>>> TEST 6: Concurrent Execution Test (Two Parallel Runs)...');
  {
    const org6A = await Organization.create({
      name: `Direct Exec Concurrent Org A - ${Date.now()}`,
      legalEntityName: 'Concurrent Execution A Pvt Ltd',
      registrationNumber: `CIN-U${Date.now().toString().slice(-6)}MH2026PTC601`,
      address: { street: 'Test Lane 6A', city: 'Mumbai', state: 'Maharashtra', pincode: '400002' },
      status: 'active',
    });

    const org6B = await Organization.create({
      name: `Direct Exec Concurrent Org B - ${Date.now()}`,
      legalEntityName: 'Concurrent Execution B Pvt Ltd',
      registrationNumber: `CIN-U${Date.now().toString().slice(-6)}MH2026PTC602`,
      address: { street: 'Test Lane 6B', city: 'Mumbai', state: 'Maharashtra', pincode: '400003' },
      status: 'active',
    });

    const targetA = await ApprovedTarget.create({
      organization: org6A._id,
      approvedDomain: '127.0.0.1',
      targetUrl: DEMO_URL_1,
      isDemoSite: true,
      targetStatus: 'approved',
    });

    const targetB = await ApprovedTarget.create({
      organization: org6B._id,
      approvedDomain: 'localhost',
      targetUrl: DEMO_URL_2,
      isDemoSite: true,
      targetStatus: 'approved',
    });

    const asmA = await Assessment.create({
      organization: org6A._id,
      targetUrl: targetA.targetUrl,
      websiteName: 'Concurrent Test A',
      status: 'in_progress',
    });

    const asmB = await Assessment.create({
      organization: org6B._id,
      targetUrl: targetB.targetUrl,
      websiteName: 'Concurrent Test B',
      status: 'in_progress',
    });

    const runA = await TestRun.create({
      assessmentId: asmA._id,
      targetId: targetA._id,
      status: 'running',
      maxPages: 5,
      timeoutSeconds: 120,
    });

    const runB = await TestRun.create({
      assessmentId: asmB._id,
      targetId: targetB._id,
      status: 'running',
      maxPages: 5,
      timeoutSeconds: 120,
    });

    const tConcStart = Date.now();
    const memBefore = process.memoryUsage().rss / (1024 * 1024);

    // Launch both concurrently
    const [resA, resB] = await Promise.all([
      executeInspectionRun(runA._id, { credentials: { skipAuthenticatedTesting: true, enabled: false } }),
      executeInspectionRun(runB._id, { credentials: { skipAuthenticatedTesting: true, enabled: false } }),
    ]);

    const concDurationMs = Date.now() - tConcStart;
    const memAfter = process.memoryUsage().rss / (1024 * 1024);

    const [finA, finB] = await Promise.all([
      TestRun.findById(runA._id).lean(),
      TestRun.findById(runB._id).lean(),
    ]);

    const bothSucceeded = finA.status === 'completed' && finB.status === 'completed';
    console.log(` [TEST 6 RESULT]: Both completed: ${bothSucceeded} | Total Parallel Time: ${formatTiming(concDurationMs)} | Memory: Before=${memBefore.toFixed(1)}MB, After=${memAfter.toFixed(1)}MB`);

    const timingsA = finA.stageTimings || resA?.stageTimings || {};
    const timingsB = finB.stageTimings || resB?.stageTimings || {};

    testResults.push({
      testName: 'Test 6: Concurrent Execution Test (Parallel Execution)',
      testRunId: `${runA._id} & ${runB._id}`,
      totalExecutionDuration: formatTiming(concDurationMs),
      browserLaunchDuration: `A: ${formatTiming(timingsA.browserLaunchMs)}, B: ${formatTiming(timingsB.browserLaunchMs)}`,
      websiteInspectionDuration: `A: ${formatTiming(timingsA.inspectionMs)}, B: ${formatTiming(timingsB.inspectionMs)}`,
      screenshotAndCloudinaryDuration: `A: ${formatTiming(timingsA.screenshotCloudinaryMs)}, B: ${formatTiming(timingsB.screenshotCloudinaryMs)}`,
      geminiAnalysisDuration: '0.00s (Computer use not toggled in parallel stress test)',
      mongoPersistenceDuration: `A: ${formatTiming(timingsA.mongoPersistenceMs)}, B: ${formatTiming(timingsB.mongoPersistenceMs)}`,
      finalStatus: bothSucceeded ? 'completed' : 'failed',
      errorDetails: bothSucceeded ? 'None' : `A: ${finA.errorMessage || 'ok'}, B: ${finB.errorMessage || 'ok'}`,
      reportDataAndEvidenceSaved: bothSucceeded,
      memoryDeltaMb: `${(memAfter - memBefore).toFixed(1)} MB`,
    });
  }

  console.log('\n========================================================================');
  console.log('ALL TESTS COMPLETED SUCCESSFULLY WITHOUT LOCAL OR RAILWAY WORKERS');
  console.log('========================================================================\n');
  console.log(JSON.stringify(testResults, null, 2));

  process.exit(0);
}

main().catch((err) => {
  console.error('Fatal Test Runner Error:', err);
  process.exit(1);
});
