import fs from 'fs';
import path from 'path';
import assert from 'assert';
import connectDB from '../lib/mongodb.js';
import Organization from '../models/Organization.js';
import ApprovedTarget from '../models/ApprovedTarget.js';
import Assessment from '../models/Assessment.js';
import AssessmentProfile from '../models/AssessmentProfile.js';
import TestRun from '../models/TestRun.js';
import Finding from '../models/Finding.js';
import ScenarioResult from '../models/ScenarioResult.js';
import Evidence from '../models/Evidence.js';
import LegalRequirement from '../models/LegalRequirement.js';
import {
  seedLegalRequirements,
  getRequirementById,
  determineLegalApplicability,
  evaluateApplicability,
  OFFICIAL_LEGAL_REQUIREMENTS,
  DPDP_REQUIREMENT_REGISTRY,
  LEGAL_REGISTRY_METADATA,
} from '../lib/requirement-registry.js';
import { evaluateAssessmentFindings } from '../lib/assessment-engine.js';
import { computeAssessmentSummary } from '../lib/assessment-summary.js';
import { generatePdfReport, generateExcelReport } from '../lib/report-generator.js';
import { validateTargetUrl } from '../lib/security.js';

// Auto-load .env.local if not already injected
if (!process.env.MONGODB_URI) {
  const envPath = path.resolve(process.cwd(), '.env.local');
  if (fs.existsSync(envPath)) {
    const lines = fs.readFileSync(envPath, 'utf8').split('\n');
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        const key = trimmed.slice(0, eqIdx).trim();
        const val = trimmed.slice(eqIdx + 1).trim().replace(/^['"]|['"]$/g, '');
        if (!process.env[key]) {
          process.env[key] = val;
        }
      }
    }
  }
}

const TEST_RUN_TAG = `board_test_${Date.now()}`;
const results = [];

function recordTest(name, passed, details = '') {
  results.push({ name, passed, details });
  const mark = passed ? '✅ PASS' : '❌ FAIL';
  console.log(`[${mark}] ${name}`);
  if (details) {
    console.log(`       ${details}`);
  }
}

async function main() {
  console.log('========================================================================');
  console.log('DPDP VAULT: 2026 LEGAL FRAMEWORK & DATA PROTECTION BOARD TEST SUITE');
  console.log('========================================================================\n');

  await connectDB();
  await seedLegalRequirements();

  // =========================================================================
  // TEST A: Registry Completeness & FAQ Provision Coverage
  // =========================================================================
  console.log('\n--- TEST A: Registry Completeness & FAQ Provision Coverage ---');
  try {
    const allReqs = await LegalRequirement.find().lean();
    assert(allReqs.length >= 25, `Expected at least 25 registered requirements, found ${allReqs.length}`);

    // Verify all key Board provisions from the supplied FAQ exist
    const expectedBoardRequirements = [
      { id: 'DPDP-ACT-SEC-2-C-BOARD-DEF', section: 'Section 2(c)', cat: 'statutory_reference' },
      { id: 'DPDP-ACT-SEC-18-BOARD-ESTABLISHMENT', section: 'Section 18', cat: 'statutory_reference' },
      { id: 'DPDP-ACT-SEC-19-1-BOARD-COMPOSITION', section: 'Section 19(1)', cat: 'statutory_reference' },
      { id: 'DPDP-ACT-SEC-19-3-MEMBER-QUALIFICATIONS', section: 'Section 19(3)', cat: 'statutory_reference' },
      { id: 'DPDP-ACT-SEC-19-2-APPOINTMENT-SELECTION', section: 'Section 19(2)', cat: 'statutory_reference' },
      { id: 'DPDP-ACT-SEC-20-2-TERM-REAPPOINTMENT', section: 'Section 20(2)', cat: 'statutory_reference' },
      { id: 'DPDP-ACT-SEC-28-1-DIGITAL-OFFICE', section: 'Section 28(1)', cat: 'statutory_reference' },
      { id: 'DPDP-ACT-SEC-27-1-A-BREACH-REMEDIAL', section: 'Section 27(1)(a)', cat: 'incident_response' },
      { id: 'DPDP-ACT-SEC-27-1-B-COMPLAINT-INQUIRY', section: 'Section 27(1)(b)', cat: 'complaint_and_grievance' },
      { id: 'DPDP-ACT-SEC-27-1-C-CONSENT-MANAGER-COMPLAINT', section: 'Section 27(1)(c)', cat: 'consent_manager_obligation' },
      { id: 'DPDP-ACT-SEC-27-1-D-CONSENT-MANAGER-REGISTRATION', section: 'Section 27(1)(d)', cat: 'consent_manager_obligation' },
      { id: 'DPDP-ACT-SEC-27-1-E-INTERMEDIARY-REFERENCE', section: 'Section 27(1)(e)', cat: 'statutory_reference' },
      { id: 'DPDP-ACT-SEC-27-2-DIRECTIONS-HEARING', section: 'Section 27(2)', cat: 'appeal_and_enforcement' },
      { id: 'DPDP-ACT-SEC-27-3-MODIFY-DIRECTIONS', section: 'Section 27(3)', cat: 'appeal_and_enforcement' },
      { id: 'DPDP-ACT-SEC-28-INQUIRY-TIMELINE', section: 'Section 28', cat: 'statutory_reference' },
      { id: 'DPDP-ACT-SEC-33-PENALTY-FACTORS', section: 'Section 33(2)', cat: 'appeal_and_enforcement' },
      { id: 'DPDP-ACT-SEC-27-RULE-9-GRIEVANCE-PREREQUISITE', section: 'Section 27, Rule 9', cat: 'complaint_and_grievance' },
      { id: 'DPDP-ACT-SEC-2-A-APPELLATE-TRIBUNAL', section: 'Section 2(a)', cat: 'appeal_and_enforcement' },
      { id: 'DPDP-ACT-SEC-29-APPEALS-TDSAT', section: 'Section 29', cat: 'appeal_and_enforcement' },
      { id: 'DPDP-ACT-SEC-29-1-APPEAL-DEADLINE', section: 'Section 29(1)', cat: 'appeal_and_enforcement' },
      { id: 'DPDP-ACT-SCHED-ENTRY-1-SECURITY-BREACH-PENALTY', section: 'Schedule Entry 1', cat: 'appeal_and_enforcement' },
    ];

    for (const exp of expectedBoardRequirements) {
      const found = allReqs.find((r) => r.requirementId === exp.id);
      assert(found, `Missing required Board FAQ entry: ${exp.id}`);
      assert(found.sectionOrRule.includes(exp.section), `Section mismatch for ${exp.id}: expected ${exp.section}, got ${found.sectionOrRule}`);
      assert.strictEqual(found.category, exp.cat, `Category mismatch for ${exp.id}: expected ${exp.cat}, got ${found.category}`);
      assert(typeof found.sourceProvenance === 'string' && found.sourceProvenance.length > 5, `Missing sourceProvenance string for ${exp.id}`);
      assert(found.lastVerifiedDate, `Missing lastVerifiedDate for ${exp.id}`);
    }

    recordTest('Test A: Registry Completeness', true, `Verified ${expectedBoardRequirements.length} Board topics with stable IDs and classifications.`);
  } catch (err) {
    recordTest('Test A: Registry Completeness', false, err.message);
  }

  // =========================================================================
  // TEST B: Legal Applicability Dates
  // =========================================================================
  console.log('\n--- TEST B: Legal Applicability Dates & Model ---');
  try {
    const boardEstReq = getRequirementById('DPDP-ACT-SEC-18-BOARD-ESTABLISHMENT');
    assert(boardEstReq, 'Board establishment requirement missing');

    // 1. Assessment date in 2024 (before commencement of 13 Nov 2025)
    const pastApp = determineLegalApplicability(boardEstReq, '2024-06-01');
    assert.strictEqual(pastApp.status, 'not_yet_in_force', '2024 assessment date must yield not_yet_in_force');
    assert.strictEqual(pastApp.isMandatoryInForce, false, 'Pre-commencement requirement must not be mandatory in-force');

    // 2. Assessment date in 2026 (after commencement of 13 Nov 2025)
    const currentApp = determineLegalApplicability(boardEstReq, '2026-06-01');
    assert.strictEqual(currentApp.status, 'in_force', '2026 assessment date must yield in_force');
    assert.strictEqual(currentApp.isMandatoryInForce, true, 'Commenced requirement must be mandatory in-force');

    // 3. Future-effective provision (Phase 2 algorithmic bias audit, effective 2027-11-13)
    const futureReq = getRequirementById('DPDP-RULES-2025-AUDIT-ALGO-CERT');
    assert(futureReq, 'Future-effective test requirement missing');
    const futureIn2026 = determineLegalApplicability(futureReq, '2026-06-01');
    assert.strictEqual(futureIn2026.status, 'not_yet_in_force', 'Future 2027 requirement in 2026 assessment must be not_yet_in_force');
    assert.strictEqual(futureIn2026.isMandatoryInForce, false, 'Future requirement must not be mandatory in-force in 2026');

    // 4. Future-effective provision evaluated in 2028
    const futureIn2028 = determineLegalApplicability(futureReq, '2028-01-01');
    assert.strictEqual(futureIn2028.status, 'in_force', 'Future requirement evaluated in 2028 must be in_force');

    // 5. Requirement with unknown effective date yields verification_required
    const verifReq = getRequirementById('DPDP-RULES-2025-CROSS-BORDER-WHITELIST');
    assert(verifReq, 'Cross-border whitelist requirement missing');
    const verifApp = determineLegalApplicability(verifReq, '2026-06-01');
    assert.strictEqual(verifApp.status, 'verification_required', 'Unknown effective date must yield verification_required');
    assert.strictEqual(verifApp.isMandatoryInForce, false, 'verification_required must not be mandatory in-force');

    recordTest('Test B: Legal Applicability Dates', true, 'Verified pre-commencement, in-force 2026, future 2027, and verification_required handling.');
  } catch (err) {
    recordTest('Test B: Legal Applicability Dates', false, err.message);
  }

  // =========================================================================
  // TEST C: Board Governance Is Not a Universal Website Requirement
  // =========================================================================
  console.log('\n--- TEST C: Board Governance Is Not a Universal Website Requirement ---');
  try {
    const orgC = await Organization.create({
      name: `Board Governance Test Org - ${TEST_RUN_TAG}`,
      legalEntityName: 'Retail Ecommerce Services Ltd',
      status: 'active',
    });

    const asmC = await Assessment.create({
      organization: orgC._id,
      targetUrl: 'https://example-shop.com',
      websiteName: 'Example Shop',
      status: 'in_progress',
      complianceScore: 0,
    });

    // Run assessment engine without any Board composition or appointment evidence
    const evalC = await evaluateAssessmentFindings(asmC._id, null, { assessmentDate: '2026-06-01' });

    // Verify Board composition and governance entries
    const boardFindings = evalC.findings.filter((f) =>
      [
        'DPDP-ACT-SEC-2-C-BOARD-DEF',
        'DPDP-ACT-SEC-18-BOARD-ESTABLISHMENT',
        'DPDP-ACT-SEC-19-1-BOARD-COMPOSITION',
        'DPDP-ACT-SEC-19-3-MEMBER-QUALIFICATIONS',
        'DPDP-ACT-SEC-19-2-APPOINTMENT-SELECTION',
        'DPDP-ACT-SEC-20-2-TERM-REAPPOINTMENT',
        'DPDP-ACT-SEC-28-1-DIGITAL-OFFICE',
      ].includes(f.requirementId)
    );

    assert(boardFindings.length >= 7, `Expected at least 7 Board governance findings, got ${boardFindings.length}`);
    for (const bf of boardFindings) {
      assert.strictEqual(
        bf.status,
        'not_applicable',
        `Board governance requirement ${bf.requirementId} must have status not_applicable, got ${bf.status}`
      );
      assert.strictEqual(
        bf.severity,
        'informational',
        `Board governance requirement ${bf.requirementId} must have informational severity, got ${bf.severity}`
      );
    }

    recordTest('Test C: Board Governance Not Universal Website Requirement', true, 'Confirmed website is not penalized for absent Board governance or selection committee info.');
  } catch (err) {
    recordTest('Test C: Board Governance Not Universal Website Requirement', false, err.message);
  }

  // =========================================================================
  // TEST D: Data Fiduciary Website Assessment with Evidence
  // =========================================================================
  console.log('\n--- TEST D: Data Fiduciary Website Assessment ---');
  try {
    const orgD = await Organization.create({
      name: `Data Fiduciary Website Test - ${TEST_RUN_TAG}`,
      legalEntityName: 'Bharat Cloud Platform Pvt Ltd',
      status: 'active',
    });

    const targetD = await ApprovedTarget.create({
      organization: orgD._id,
      approvedDomain: 'bharatcloud.in',
      targetUrl: 'https://bharatcloud.in',
      targetStatus: 'approved',
    });

    await AssessmentProfile.create({
      organization: orgD._id,
      approvedTarget: targetD._id,
      websiteUrl: targetD.targetUrl,
      websiteFeatures: [
        { key: 'contact_forms', label: 'Contact Forms', enabled: true },
        { key: 'cookies_analytics', label: 'Cookies & Analytics', enabled: true },
        { key: 'registration_login', label: 'Registration & Login', enabled: true },
      ],
      websiteCapabilities: {
        contact_forms: true,
        user_registration_login: true,
        cookies_analytics: true,
      },
    });

    const asmD = await Assessment.create({
      organization: orgD._id,
      targetUrl: targetD.targetUrl,
      websiteName: 'Bharat Cloud',
      status: 'in_progress',
      complianceScore: 0,
    });

    const testRunD = await TestRun.create({
      assessmentId: asmD._id,
      targetId: targetD._id,
      status: 'completed',
      progress: 100,
      currentStep: 'Completed evaluation',
    });

    // Provide controlled scenario results
    await ScenarioResult.create([
      {
        testRunId: testRunD._id,
        assessmentId: asmD._id,
        scenarioId: 'privacy_notice_compliance',
        title: 'Privacy Notice Section 5 Evaluation',
        summary: 'Itemized disclosures and notice accessibility verified.',
        status: 'passed',
        observedFindings: ['Itemized purpose list observed', 'Contact email of DPO published'],
      },
      {
        testRunId: testRunD._id,
        assessmentId: asmD._id,
        scenarioId: 'consent_mechanism_sec_6',
        title: 'Consent Affirmative Action Evaluation',
        summary: 'Affirmative consent mechanism and opt-in verified.',
        status: 'passed',
        observedFindings: ['Explicit opt-in checkbox observed', 'No pre-ticked checkboxes'],
      },
      {
        testRunId: testRunD._id,
        assessmentId: asmD._id,
        scenarioId: 'grievance_mechanism_sec_8_9',
        title: 'Grievance Redressal Mechanism Evaluation',
        summary: 'Designated Grievance Officer and contact details verified.',
        status: 'passed',
        observedFindings: ['Designated Grievance Redressal Officer published with direct email and 30-day resolution timeline'],
      },
    ]);

    const evalD = await evaluateAssessmentFindings(asmD._id, testRunD._id, { assessmentDate: '2026-06-01' });

    // Verify Section 5 passed
    const noticeFinding = evalD.findings.find((f) => f.requirementId === 'DPDP-ACT-SEC-5-NOTICE');
    assert(noticeFinding && noticeFinding.status === 'pass', 'Section 5 Notice must pass when evidence passes');

    // Verify Section 6 passed
    const consentFinding = evalD.findings.find((f) => f.requirementId === 'DPDP-ACT-SEC-6-CONSENT-ITEMIZED');
    assert(consentFinding && consentFinding.status === 'pass', 'Section 6 Consent must pass when evidence passes');

    // Verify Section 8(9) & Rule 9 grievance prerequisite passed
    const grievanceFinding = evalD.findings.find((f) => f.requirementId === 'DPDP-ACT-SEC-27-RULE-9-GRIEVANCE-PREREQUISITE');
    assert(grievanceFinding && grievanceFinding.status === 'pass', 'Grievance prerequisite finding must pass when evidence passes');

    // Compliance score must be calculated exclusively from applicable requirements
    assert(evalD.complianceScore >= 50, `Compliance score expected >= 50, got ${evalD.complianceScore}`);
    assert(evalD.counts.pass >= 3, `Expected at least 3 passing controls, got ${evalD.counts.pass}`);

    recordTest('Test D: Data Fiduciary Website Assessment', true, `Evaluated website evidence; compliance score: ${evalD.complianceScore}%. Board entries did not cause failures.`);
  } catch (err) {
    recordTest('Test D: Data Fiduciary Website Assessment', false, err.message);
  }

  // =========================================================================
  // TEST E: Consent Manager Applicability
  // =========================================================================
  console.log('\n--- TEST E: Consent Manager Applicability ---');
  try {
    // 1. Ordinary website: uses cookie banner/toggles, but is NOT a registered Consent Manager
    const orgOrdinary = await Organization.create({
      name: `Ordinary Website Org - ${TEST_RUN_TAG}`,
      legalEntityName: 'Standard Content Portal Ltd',
      status: 'active',
    });
    const targetOrdinary = await ApprovedTarget.create({
      organization: orgOrdinary._id,
      approvedDomain: 'ordinary-portal.in',
      targetUrl: 'https://ordinary-portal.in',
      targetStatus: 'approved',
    });
    const profileOrdinary = await AssessmentProfile.create({
      organization: orgOrdinary._id,
      approvedTarget: targetOrdinary._id,
      websiteUrl: targetOrdinary.targetUrl,
      isConsentManager: false,
    });

    const appListOrdinary = evaluateApplicability(orgOrdinary, profileOrdinary, '2026-06-01');
    const cmReqsOrdinary = appListOrdinary.filter((item) =>
      ['DPDP-ACT-SEC-27-1-C-CONSENT-MANAGER-COMPLAINT', 'DPDP-ACT-SEC-27-1-D-CONSENT-MANAGER-REGISTRATION'].includes(
        item.requirement.requirementId
      )
    );

    for (const cmItem of cmReqsOrdinary) {
      assert.strictEqual(
        cmItem.isApplicable,
        false,
        `Consent Manager requirement ${cmItem.requirement.requirementId} must not apply to ordinary website`
      );
      assert(cmItem.reason.includes('Consent Manager'), `Expected reason to note Consent Manager classification, got ${cmItem.reason}`);
    }

    // 2. Organization explicitly registered as a Consent Manager
    const orgCM = await Organization.create({
      name: `Registered Consent Manager Fixture - ${TEST_RUN_TAG}`,
      legalEntityName: 'Sammathi Consent Interoperability Foundation',
      status: 'active',
    });
    const targetCM = await ApprovedTarget.create({
      organization: orgCM._id,
      approvedDomain: 'sammathi.org.in',
      targetUrl: 'https://sammathi.org.in',
      targetStatus: 'approved',
    });
    const profileCM = await AssessmentProfile.create({
      organization: orgCM._id,
      approvedTarget: targetCM._id,
      websiteUrl: targetCM.targetUrl,
      isConsentManager: true,
    });

    const appListCM = evaluateApplicability(orgCM, profileCM, '2026-06-01');
    const cmReqsCM = appListCM.filter((item) =>
      ['DPDP-ACT-SEC-27-1-C-CONSENT-MANAGER-COMPLAINT', 'DPDP-ACT-SEC-27-1-D-CONSENT-MANAGER-REGISTRATION'].includes(
        item.requirement.requirementId
      )
    );

    for (const cmItem of cmReqsCM) {
      assert.strictEqual(
        cmItem.isApplicable,
        true,
        `Consent Manager requirement ${cmItem.requirement.requirementId} must apply to registered Consent Manager`
      );
    }

    recordTest('Test E: Consent Manager Applicability', true, 'Ordinary website excluded from Consent Manager obligations; CM fixture correctly evaluated.');
  } catch (err) {
    recordTest('Test E: Consent Manager Applicability', false, err.message);
  }

  // =========================================================================
  // TEST F: Complaint and Appeal Claims
  // =========================================================================
  console.log('\n--- TEST F: Complaint and Appeal Claims ---');
  try {
    // Verify that appellate provisions exist with correct statutory deadlines and TDSAT reference
    const appealTribunalReq = getRequirementById('DPDP-ACT-SEC-2-A-APPELLATE-TRIBUNAL');
    assert(appealTribunalReq, 'Appellate tribunal requirement missing');
    assert(appealTribunalReq.expectedControl.includes('TDSAT'), 'Must identify TDSAT as Appellate Tribunal');

    const appealDeadlineReq = getRequirementById('DPDP-ACT-SEC-29-1-APPEAL-DEADLINE');
    assert(appealDeadlineReq, 'Appeal deadline requirement missing');
    assert(appealDeadlineReq.expectedControl.includes('60 days'), 'Appeal deadline must specify 60 days under Section 29(1)');

    const inquiryTimelineReq = getRequirementById('DPDP-ACT-SEC-28-INQUIRY-TIMELINE');
    assert(inquiryTimelineReq, 'Inquiry timeline requirement missing');
    assert(inquiryTimelineReq.expectedControl.includes('6 months'), 'Inquiry timeline must state 6 months with recorded reasons for extension');

    // Verify non-penalization: None of these are marked as website-level compliance checks
    assert.strictEqual(appealTribunalReq.isWebsiteComplianceCheck, false, 'Appellate tribunal is not a website check');
    assert.strictEqual(appealDeadlineReq.isWebsiteComplianceCheck, false, 'Appeal deadline is not a website check');
    assert.strictEqual(inquiryTimelineReq.isWebsiteComplianceCheck, false, 'Inquiry timeline is not a website check');

    recordTest('Test F: Complaint and Appeal Claims', true, 'Verified TDSAT, 60-day appeal deadline, and 6-month inquiry timeline without website misattribution.');
  } catch (err) {
    recordTest('Test F: Complaint and Appeal Claims', false, err.message);
  }

  // =========================================================================
  // TEST G: Penalty References & Schedule Matching
  // =========================================================================
  console.log('\n--- TEST G: Penalty References & Schedule Matching ---');
  try {
    const penaltyReq1 = getRequirementById('DPDP-ACT-SCHED-ENTRY-1-SECURITY-BREACH-PENALTY');
    assert(penaltyReq1, 'Schedule penalties Item 1 requirement missing');
    assert.strictEqual(penaltyReq1.penaltyReference?.maxPenaltyAmountInr, 25000000000, 'Max penalty must be 250 crore INR');
    assert(
      (penaltyReq1.penaltyReference?.maxPenaltyText || penaltyReq1.penaltyReference?.maxPenaltyAmount || '')
        .toLowerCase()
        .includes('250 crore'),
      'Max penalty text must cite 250 crore'
    );

    // Verify factors considered under Section 33(2)
    const factorsReq = getRequirementById('DPDP-ACT-SEC-33-PENALTY-FACTORS');
    assert(factorsReq, 'Penalty factors requirement missing');
    assert(factorsReq.sectionOrRule.includes('Section 33(2)'), 'Must cite Section 33(2)');

    // Verify specific Schedule Items across requirements:
    // Security safeguards breach (Schedule Item 1) -> Up to 250 crore
    const sec85Req = getRequirementById('DPDP-ACT-SEC-8-5-SECURITY-SAFEGUARDS');
    assert(
      (sec85Req?.penaltyReference?.maxPenaltyText || sec85Req?.penaltyReference?.maxPenaltyAmount || '')
        .toLowerCase()
        .includes('250 crore'),
      'Section 8(5) must reference max 250 crore'
    );

    // Children data breach (Schedule Item 3) -> Up to 200 crore
    const sec9Req = getRequirementById('DPDP-ACT-SEC-9-CHILDREN-DATA');
    assert(
      (sec9Req?.penaltyReference?.maxPenaltyText || sec9Req?.penaltyReference?.maxPenaltyAmount || '')
        .toLowerCase()
        .includes('200 crore'),
      'Section 9 must reference max 200 crore'
    );

    // Consent Manager breach (Schedule Item 6) -> Up to 50 crore
    const cmBreachReq = getRequirementById('DPDP-ACT-SEC-27-1-D-CONSENT-MANAGER-REGISTRATION');
    assert(
      (cmBreachReq?.penaltyReference?.maxPenaltyText || cmBreachReq?.penaltyReference?.maxPenaltyAmount || '')
        .toLowerCase()
        .includes('50 crore'),
      'CM registration breach must reference max 50 crore'
    );

    recordTest('Test G: Penalty References', true, 'Verified Schedule caps (max 250 crore for Sec 8(5), 200 crore for Sec 9, 50 crore for CM) and Sec 33(2) factors.');
  } catch (err) {
    recordTest('Test G: Penalty References', false, err.message);
  }

  // =========================================================================
  // TEST H: Report Persistence and PDF/Excel Rendering
  // =========================================================================
  console.log('\n--- TEST H: Report Persistence and Rendering ---');
  try {
    const orgH = await Organization.create({
      name: `Report Rendering Test Org - ${TEST_RUN_TAG}`,
      legalEntityName: 'Statutory Reports Test Ltd',
      status: 'active',
    });

    const asmH = await Assessment.create({
      organization: orgH._id,
      targetUrl: 'https://statutory-reporting-test.in',
      websiteName: 'Statutory Reporting Test',
      status: 'in_progress',
      complianceScore: 0,
    });

    // Evaluate findings
    const evalH = await evaluateAssessmentFindings(asmH._id, null, { assessmentDate: '2026-06-01' });

    // Verify findings are persisted in MongoDB with 2026 fields
    const persistedFindings = await Finding.find({ assessment: asmH._id }).lean();
    assert(persistedFindings.length > 0, 'Findings must be persisted to MongoDB');

    const sampleFinding = persistedFindings.find((f) => f.requirementId === 'DPDP-ACT-SEC-18-BOARD-ESTABLISHMENT');
    assert(sampleFinding, 'Board establishment finding must exist in MongoDB');
    assert.strictEqual(sampleFinding.legalApplicabilityStatus, 'in_force', 'Legal status must be persisted');
    assert(sampleFinding.officialSource, 'Official source must be persisted');
    assert.strictEqual(sampleFinding.registryVersion, '2026.1', 'Registry version must be 2026.1');

    // Test PDF Report generation
    const pdfBuffer = await generatePdfReport(asmH._id);
    assert(Buffer.isBuffer(pdfBuffer), 'generatePdfReport must return a Buffer');
    assert(pdfBuffer.length > 1000, `PDF buffer too small: ${pdfBuffer.length} bytes`);
    assert(pdfBuffer.toString('utf8', 0, 5) === '%PDF-', 'Buffer must be a valid PDF file starting with %PDF-');

    // Test Excel Report generation
    const excelBuffer = await generateExcelReport(asmH._id);
    assert(Buffer.isBuffer(excelBuffer), 'generateExcelReport must return a Buffer');
    assert(excelBuffer.length > 1000, `Excel buffer too small: ${excelBuffer.length} bytes`);

    // Verify computeAssessmentSummary does not distort compliance score
    const updatedAsmH = await Assessment.findById(asmH._id).lean();
    const summary = computeAssessmentSummary({
      assessment: updatedAsmH,
      findings: persistedFindings,
    });
    assert(summary.complianceScore !== null, 'Compliance score must be computed');
    assert(summary.counts.not_applicable > 0, 'Not applicable count must include statutory references');

    recordTest('Test H: Report Persistence & Rendering', true, `Generated valid PDF (${pdfBuffer.length} bytes) and Excel (${excelBuffer.length} bytes) reports with 2026 legal metadata.`);
  } catch (err) {
    recordTest('Test H: Report Persistence & Rendering', false, err.message);
  }

  // =========================================================================
  // TEST I: Regression Tests (SSRF, URL Validation, Score Formula)
  // =========================================================================
  console.log('\n--- TEST I: Regression Tests ---');
  try {
    // 1. SSRF & URL validation
    const awsMeta = validateTargetUrl('http://169.254.169.254/latest/meta-data/');
    assert.strictEqual(awsMeta.isValid, false, 'AWS metadata IP must be rejected');

    const privateIp = validateTargetUrl('http://10.0.0.1/admin');
    assert.strictEqual(privateIp.isValid, false, 'Private IP must be rejected');

    const fileScheme = validateTargetUrl('file:///etc/passwd');
    assert.strictEqual(fileScheme.isValid, false, 'File scheme must be rejected');

    const validPublic = validateTargetUrl('https://example.com');
    assert.strictEqual(validPublic.isValid, true, 'Public HTTPS URL must be valid');

    // 2. Score Formula Regression:
    // Pure function check of computeAssessmentSummary score logic
    const mockFindings = [
      { status: 'pass', severity: 'high' },
      { status: 'fail', severity: 'critical' },
      { status: 'needs_review', severity: 'medium' },
      { status: 'not_applicable', severity: 'informational' }, // Excluded from denominator
      { status: 'not_applicable', severity: 'informational' }, // Excluded from denominator
      { status: 'not_tested', severity: 'informational' },     // Excluded from denominator
    ];
    // Actionable = 1 pass + 1 fail + 1 needs_review = 3. Pass = 1. Score = Math.round(1/3 * 100) = 33%
    const mockSummary = computeAssessmentSummary({
      assessment: { status: 'completed', targetUrl: 'https://test.com' },
      findings: mockFindings,
    });
    assert.strictEqual(mockSummary.complianceScore, 33, `Expected score 33%, got ${mockSummary.complianceScore}%`);
    assert.strictEqual(mockSummary.counts.not_applicable, 2, 'Expected 2 not_applicable counts');
    assert.strictEqual(mockSummary.actionableCount, 3, 'Expected actionable count = 3');

    recordTest('Test I: Regression Tests', true, 'Verified SSRF rejection, URL sanitization, and score formula integrity (excluding N/A and not_tested).');
  } catch (err) {
    recordTest('Test I: Regression Tests', false, err.message);
  }

  // =========================================================================
  // TEST SUMMARY
  // =========================================================================
  console.log('\n========================================================================');
  console.log('TEST SUMMARY');
  console.log('========================================================================');
  const total = results.length;
  const passed = results.filter((r) => r.passed).length;
  const failed = total - passed;

  console.log(`Total Scenarios: ${total}`);
  console.log(`Passed:          ${passed}`);
  console.log(`Failed:          ${failed}`);

  if (failed > 0) {
    console.error('\n❌ SOME TESTS FAILED:');
    for (const r of results.filter((r) => !r.passed)) {
      console.error(`  - ${r.name}: ${r.details}`);
    }
    process.exit(1);
  } else {
    console.log('\n🎉 ALL 2026 LEGAL FRAMEWORK & DATA PROTECTION BOARD TESTS PASSED!');
    process.exit(0);
  }
}

main().catch((err) => {
  console.error('Unhandled test suite error:', err);
  process.exit(1);
});
